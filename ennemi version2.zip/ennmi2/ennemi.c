
#include "ennemi.h"

void initEnnemi(Ennemi *e)
{
    static int init = 0;
    if(!init) {
        srand(time(NULL));
        init = 1;
    }
    
    e->posEnnemi.x = 100;
    e->posEnnemi.y = 400;
    e->posEnnemi.w = 80;
    e->posEnnemi.h = 100;
    e->posDepart.x = 100;
    e->posDepart.y = 400;
    e->posArrivee.x = 700;
    e->posArrivee.y = 400;
    e->direction = 0;
    e->vitesse = 3;
    e->vie = 100;
    e->actif = 1;
    e->degats = 10;
    e->frameActuelle = 0;
    e->compteurAnimation = 0;
    e->niveau = 1;
    e->angleVague = 0;
    
    for(int i = 0; i < 5; i++) {
        e->textures[i] = NULL;
    }
}

void chargerTextures(Ennemi *e, SDL_Renderer *renderer)
{
    char chemin[100];
    char prefixe[20];
    
    if(e->niveau == 1) {
        sprintf(prefixe, "ennemi_");
    } else {
        sprintf(prefixe, "ennemi2_");
    }
    
    for(int i = 0; i < 5; i++) {
        sprintf(chemin, "%s%d.png", prefixe, i+1);
        SDL_Surface* surface = IMG_Load(chemin);
        if(surface) {
            e->textures[i] = SDL_CreateTextureFromSurface(renderer, surface);
            SDL_FreeSurface(surface);
        } else {
            e->textures[i] = NULL;
        }
    }
}

void afficherEnnemi(Ennemi e, SDL_Renderer *renderer)
{
    if(renderer && e.actif && e.textures[e.frameActuelle]) {
        SDL_RenderCopy(renderer, e.textures[e.frameActuelle], NULL, &e.posEnnemi);
    }
}

void updateEnnemi(Ennemi *e)
{
    if(!e->actif) return;
    
    e->compteurAnimation++;
    if(e->compteurAnimation >= 8) {
        e->compteurAnimation = 0;
        e->frameActuelle++;
        if(e->frameActuelle >= 5) {
            e->frameActuelle = 0;
        }
    }
    
    if(e->niveau == 1) {
        if(e->direction == 0) {
            e->posEnnemi.x += e->vitesse;
            if(e->posEnnemi.x + e->posEnnemi.w >= e->posArrivee.x) {
                e->posEnnemi.x = e->posArrivee.x - e->posEnnemi.w;
                e->direction = 1;
            }
        } else {
            e->posEnnemi.x -= e->vitesse;
            if(e->posEnnemi.x <= e->posDepart.x) {
                e->posEnnemi.x = e->posDepart.x;
                e->direction = 0;
            }
        }
    }
    else {
        if(e->direction == 0) {
            e->posEnnemi.x += e->vitesse;
            if(e->posEnnemi.x + e->posEnnemi.w >= e->posArrivee.x) {
                e->posEnnemi.x = e->posArrivee.x - e->posEnnemi.w;
                e->direction = 1;
            }
        } else {
            e->posEnnemi.x -= e->vitesse;
            if(e->posEnnemi.x <= e->posDepart.x) {
                e->posEnnemi.x = e->posDepart.x;
                e->direction = 0;
            }
        }
        e->angleVague += 0.1;
        e->posEnnemi.y = e->posDepart.y + (int)(40 * sin(e->angleVague));
    }
}

void ennemietats(Ennemi *e, int degats)
{
    if(!e->actif) return;
    
    e->vie -= degats;
    if(e->vie <= 0) {
        e->actif = 0;
    }
}

int collisionBB(perso p, Ennemi e)
{
    if(!e.actif) return 0;
    
    if((p.poshero.x + p.poshero.w < e.posEnnemi.x) ||
       (p.poshero.x > e.posEnnemi.x + e.posEnnemi.w) ||
       (p.poshero.y + p.poshero.h < e.posEnnemi.y) ||
       (p.poshero.y > e.posEnnemi.y + e.posEnnemi.h)) {
        return 0;
    }
    return 1;
}

void gererCollision(perso *p, Ennemi *e)
{
    if(!e->actif) return;
    
    if(collisionBB(*p, *e)) {
        unsigned int currentTime = SDL_GetTicks();
        if(currentTime - p->lastHit > 1000) {
            p->vie -= e->degats;
            p->lastHit = currentTime;
        }
    }
}
