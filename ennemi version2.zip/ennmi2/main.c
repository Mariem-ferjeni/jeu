
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "ennemi.h"

int main(int argc, char *argv[])
{
    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;
    SDL_Event event;
    int continuer = 1;
    int niveauActuel = 1;
    int toucheNPrecedente = 0;
    
    if(SDL_Init(SDL_INIT_VIDEO) < 0) {
        return 1;
    }
    
    if(!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        SDL_Quit();
        return 1;
    }
    
    window = SDL_CreateWindow("Enemy - 2 Trajectoires", SDL_WINDOWPOS_CENTERED,
                              SDL_WINDOWPOS_CENTERED, 800, 500,
                              SDL_WINDOW_SHOWN);
    if(!window) {
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if(!renderer) {
        SDL_DestroyWindow(window);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    
    SDL_Texture* backgroundNiveau1 = NULL;
    SDL_Texture* backgroundNiveau2 = NULL;
    SDL_Texture* backgroundActuel = NULL;
    
    SDL_Surface* surface = IMG_Load("bg.png");
    if(surface) {
        backgroundNiveau1 = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_FreeSurface(surface);
    }
    
    surface = IMG_Load("bg2.png");
    if(surface) {
        backgroundNiveau2 = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_FreeSurface(surface);
    }
    
    backgroundActuel = backgroundNiveau1;
    
    surface = IMG_Load("joueur.png");
    if(!surface) {
        return 1;
    }
    SDL_Texture* joueurTexture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);
    
    perso player;
    player.poshero.x = 700;
    player.poshero.y = 400;
    player.poshero.w = 60;
    player.poshero.h = 100;
    player.texture = joueurTexture;
    player.vie = 100;
    player.invincible = 0;
    player.lastHit = 0;
    
    Ennemi enemy;
    initEnnemi(&enemy);
    chargerTexturesEnnemi(&enemy, renderer);
    
    int mouseX, mouseY;
    
    while(continuer) {
        while(SDL_PollEvent(&event)) {
            if(event.type == SDL_QUIT) {
                continuer = 0;
            }
            
            if(event.type == SDL_KEYDOWN) {
                if(event.key.keysym.sym == SDLK_n && !toucheNPrecedente) {
                    toucheNPrecedente = 1;
                    if(niveauActuel == 1) {
                        niveauActuel = 2;
                        backgroundActuel = backgroundNiveau2;
                        enemy.niveau = 2;
                        enemy.posEnnemi.x = 100;
                        enemy.posEnnemi.y = 350;
                        enemy.posDepart.x = 100;
                        enemy.posDepart.y = 350;
                        enemy.posArrivee.x = 700;
                        enemy.posArrivee.y = 350;
                        enemy.direction = 0;
                        enemy.vie = 100;
                        enemy.actif = 1;
                        enemy.angleVague = 0;
                        chargerTexturesEnnemi(&enemy, renderer);
                    } else {
                        niveauActuel = 1;
                        backgroundActuel = backgroundNiveau1;
                        enemy.niveau = 1;
                        enemy.posEnnemi.x = 100;
                        enemy.posEnnemi.y = 400;
                        enemy.posDepart.x = 100;
                        enemy.posDepart.y = 400;
                        enemy.posArrivee.x = 700;
                        enemy.posArrivee.y = 400;
                        enemy.direction = 0;
                        enemy.vie = 100;
                        enemy.actif = 1;
                        chargerTexturesEnnemi(&enemy, renderer);
                    }
                }
            }
            
            if(event.type == SDL_KEYUP) {
                if(event.key.keysym.sym == SDLK_n) {
                    toucheNPrecedente = 0;
                }
            }
            
            if(event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                mouseX = event.button.x;
                mouseY = event.button.y;
                if(enemy.actif &&
                   mouseX >= enemy.posEnnemi.x && mouseX <= enemy.posEnnemi.x + enemy.posEnnemi.w &&
                   mouseY >= enemy.posEnnemi.y && mouseY <= enemy.posEnnemi.y + enemy.posEnnemi.h) {
                    ennemiPrendreDegats(&enemy, 20);
                }
            }
        }
        
        updateEnnemi(&enemy);
        gererCollision(&player, &enemy);
        
        if(player.vie <= 0 || !enemy.actif) {
            break;
        }
        
        SDL_RenderClear(renderer);
        
        if(backgroundActuel) {
            SDL_RenderCopy(renderer, backgroundActuel, NULL, NULL);
        } else {
            SDL_SetRenderDrawColor(renderer, 50, 50, 50, 255);
            SDL_RenderClear(renderer);
        }
        
        SDL_RenderCopy(renderer, player.texture, NULL, &player.poshero);
        afficherEnnemi(enemy, renderer);
        
        SDL_Rect barreJoueur = {10, 10, player.vie * 2, 20};
        SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
        SDL_RenderFillRect(renderer, &barreJoueur);
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_Rect contourJ = {10, 10, 200, 20};
        SDL_RenderDrawRect(renderer, &contourJ);
        
        int barreLargeur = enemy.vie * 2;
        if(barreLargeur < 0) barreLargeur = 0;
        SDL_Rect barreEnnemi = {800 - barreLargeur - 10, 10, barreLargeur, 20};
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(renderer, &barreEnnemi);
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_Rect contourE = {800 - 210, 10, 200, 20};
        SDL_RenderDrawRect(renderer, &contourE);
        
        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }
    
    if(backgroundNiveau1) SDL_DestroyTexture(backgroundNiveau1);
    if(backgroundNiveau2) SDL_DestroyTexture(backgroundNiveau2);
    if(joueurTexture) SDL_DestroyTexture(joueurTexture);
    
    for(int i = 0; i < 5; i++) {
        if(enemy.textures[i]) SDL_DestroyTexture(enemy.textures[i]);
    }
    
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
    
    return 0;
}
