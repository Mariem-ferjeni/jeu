#include "ennemi.h"

void initEnnemi(Ennemi *e)
{
    int init = 0;
    
    init = 1;
    srand(time(NULL));
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printf("Erreur audio: %s\n", Mix_GetError());
    }
    if(TTF_Init() < 0) {
        printf("Erreur TTF: %s\n", TTF_GetError());
    }
    
    e->posEnnemi.x = 100;
    e->posEnnemi.y = 400;
    e->posEnnemi.w = 80;
    e->posEnnemi.h = 100;
    e->posDepart.x = 100;
    e->posDepart.y = 400;
    e->posArrivee.x = 700;
    e->posArrivee.y = 400;
    e->direction = 0;
    e->vitesse = 3;
    e->vitesseOriginale = 3;
    e->vie = 100;
    e->actif = 1;
    e->degats = 10;
    e->frameActuelle = 0;
    e->compteurAnimation = 0;
    e->niveau = 1;
    e->angleVague = 0;
    e->clignotement = 0;
    e->tempsDernierDegat = 0;
    
    for(int i = 0; i < 5; i++) {
        e->textures[i] = NULL;
    }
}

void chargerTextures(Ennemi *e, SDL_Renderer *renderer)
{
    char chemin[100];
    char prefixe[20];
    
    if(e->niveau == 1) {
        sprintf(prefixe, "ennemi_");
    } else {
        sprintf(prefixe, "ennemi2_");
    }
    
    for(int i = 0; i < 5; i++) {
        sprintf(chemin, "%s%d.png", prefixe, i+1);
        SDL_Surface* surface = IMG_Load(chemin);
        if(surface) {
            e->textures[i] = SDL_CreateTextureFromSurface(renderer, surface);
            SDL_FreeSurface(surface);
        } else {
            e->textures[i] = NULL;
        }
    }
}

void afficherEnnemi(Ennemi e, SDL_Renderer *renderer)
{
    if(renderer && e.actif && e.textures[e.frameActuelle]) {
        if(e.clignotement > 0 && (SDL_GetTicks() / 100) % 2 == 0) {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_RenderFillRect(renderer, &e.posEnnemi);
        } else {
            SDL_RenderCopy(renderer, e.textures[e.frameActuelle], NULL, &e.posEnnemi);
        }
    }
}

void updateEnnemi(Ennemi *e)
{
    if(!e->actif) return;
    
    if(e->clignotement > 0 && SDL_GetTicks() - e->tempsDernierDegat > 500) {
        e->clignotement = 0;
    }
    
    e->compteurAnimation++;
    if(e->compteurAnimation >= 8) {
        e->compteurAnimation = 0;
        e->frameActuelle++;
        if(e->frameActuelle >= 5) {
            e->frameActuelle = 0;
        }
    }
    
    if(e->vitesse > e->vitesseOriginale) {
        if(e->vitesse > e->vitesseOriginale + 2) {
            e->vitesse = e->vitesseOriginale;
        } else {
            e->vitesse--;
        }
    }
    
    if(e->niveau == 1) {
        if(e->direction == 0) {
            e->posEnnemi.x += e->vitesse;
            if(e->posEnnemi.x + e->posEnnemi.w >= e->posArrivee.x) {
                e->posEnnemi.x = e->posArrivee.x - e->posEnnemi.w;
                e->direction = 1;
            }
        } else {
            e->posEnnemi.x -= e->vitesse;
            if(e->posEnnemi.x <= e->posDepart.x) {
                e->posEnnemi.x = e->posDepart.x;
                e->direction = 0;
            }
        }
    }
    else {
        if(e->direction == 0) {
            e->posEnnemi.x += e->vitesse;
            if(e->posEnnemi.x + e->posEnnemi.w >= e->posArrivee.x) {
                e->posEnnemi.x = e->posArrivee.x - e->posEnnemi.w;
                e->direction = 1;
            }
        } else {
            e->posEnnemi.x -= e->vitesse;
            if(e->posEnnemi.x <= e->posDepart.x) {
                e->posEnnemi.x = e->posDepart.x;
                e->direction = 0;
            }
        }
        e->angleVague += 0.1;
        e->posEnnemi.y = e->posDepart.y + (int)(40 * sin(e->angleVague));
    }
}

void ennemietat(Ennemi *e, int degats)
{
    if(!e->actif) return;
    
    e->vie -= degats;
    e->clignotement = 1;
    e->tempsDernierDegat = SDL_GetTicks();
    
    if(e->vitesse > 1) {
        e->vitesse = e->vitesseOriginale / 2;
        if(e->vitesse < 1) e->vitesse = 1;
    }
    
    if(e->vie <= 0) {
        e->actif = 0;
    }
}

int collisionBB(perso p, Ennemi e)
{
    if(!e.actif) return 0;
    
    if((p.poshero.x + p.poshero.w < e.posEnnemi.x) ||
       (p.poshero.x > e.posEnnemi.x + e.posEnnemi.w) ||
       (p.poshero.y + p.poshero.h < e.posEnnemi.y) ||
       (p.poshero.y > e.posEnnemi.y + e.posEnnemi.h)) {
        return 0;
    }
    return 1;
}

void gererCollision(perso *p, Ennemi *e, Coin *coin)
{
    if(collisionBB(*p, *e)) {
        int currentTime = SDL_GetTicks();
        if(currentTime - p->lastHit > 1000) {
            p->vie -= 10;
            if(p->vie < 0) p->vie = 0;
            p->lastHit = currentTime;
            e->vitesse += 2;
            printf("Joueur touche par ennemi! Vie: %d\n", p->vie);
        }
    }
    
    if(coin->actif) {
        if((p->poshero.x + p->poshero.w > coin->rect.x) &&
           (p->poshero.x < coin->rect.x + coin->rect.w) &&
           (p->poshero.y + p->poshero.h > coin->rect.y) &&
           (p->poshero.y < coin->rect.y + coin->rect.h)) {
            
            coin->actif = 0;
            coin->respawnTimer = 60;
            
            p->vie += 10;
            if(p->vie > 100) p->vie = 100;
            printf("Coin ramasse! +10 vie, Vie: %d\n", p->vie);
        }
    }
    
    if(!coin->actif) {
        coin->respawnTimer--;
        if(coin->respawnTimer <= 0) {
            coin->actif = 1;
            coin->rect.x = 50 + (rand() % 700);
            coin->rect.y = 430;
            coin->vitesseY = 0;
            coin->respawnTimer = 0;
            printf("Coin reapparu!\n");
        }
    }
}

void afficherTexte(SDL_Renderer *renderer, TTF_Font *police, char *texte, int x, int y, SDL_Color couleur)
{
    SDL_Surface* surface = TTF_RenderText_Solid(police, texte, couleur);
    if(surface) {
        SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_Rect rect = {x, y, surface->w, surface->h};
        SDL_RenderCopy(renderer, texture, NULL, &rect);
        SDL_FreeSurface(surface);
        SDL_DestroyTexture(texture);
    }
}
